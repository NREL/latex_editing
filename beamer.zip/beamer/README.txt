2015-12-01: NREL Beamer Template
There are four style (.sty) files associated with this template:
1. "beamerthemeNREL.sty"
2. "beamercolorthemeNREL.sty"
3. "beamerinnerthemeNREL.sty"
4. "beamerouterthemeNREL.sty";
two image (.png) files:
1. "NREL_Logo.png"
2. "NREL_Banner.png";
and one latex (.tex) file:
1. "NREL_Beamer_Template.tex".
For users with MiKTeX 2.9, the style files can be moved to the analogous folders
within the directory "C:\Program Files (x86)\MiKTeX 2.9\tex\latex\beamer\base\themes",
while the image files can be placed within the "inner" folder.  After moving the files,
the user should run "mo.exe" from the directory "C:\Program Files (x86)\MiKTeX 2.9\miktex\bin\x64"
and select "Refresh FNDB".  The file "NREL_Beamer_Template.tex" can be located in any
folder and used to create new beamer documents.